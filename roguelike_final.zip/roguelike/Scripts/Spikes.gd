extends Area2D

@export var speed := 300.0
@export var damage := 10

var direction := Vector2.RIGHT


func _ready() -> void:
	body_entered.connect(_on_body_entered)

	# Assumes the spike artwork points right by default.
	rotation = direction.angle()


func _physics_process(delta: float) -> void:
	global_position += direction * speed * delta


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player") and body.has_method("take_damage"):
		body.take_damage(damage)
		queue_free()
