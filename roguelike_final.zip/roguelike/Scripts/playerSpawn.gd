extends Node2D

@export var player_scene: PackedScene
@onready var player_spawn: Marker2D = $PlayerSpawn

func _ready() -> void:
	if player_scene == null:
		push_error("Asigna Jugador.tscn en el campo Jugador Escena.")
		return

	var jugador = player_scene.instantiate()
	add_child(jugador)
	jugador.global_position = player_spawn.global_position
