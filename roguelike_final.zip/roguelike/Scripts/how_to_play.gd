extends TextureButton

@export var hover_scale := 1.15
@export var idle_scale := 1.04
var normal_scale := Vector2.ONE
var scale_tween: Tween


func _ready() -> void:
	normal_scale = scale
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)
	start_idle_animation()


func _on_mouse_entered() -> void:
	stop_scale_tween()
	animate_scale(normal_scale * hover_scale, 0.25)


func _on_mouse_exited() -> void:
	stop_scale_tween()
	scale_tween = create_tween()
	scale_tween.tween_property(self, "scale", normal_scale, 0.25)
	scale_tween.tween_callback(start_idle_animation)


func start_idle_animation() -> void:
	stop_scale_tween()
	scale = normal_scale
	scale_tween = create_tween().set_loops()
	scale_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	scale_tween.tween_property(self, "scale", normal_scale * idle_scale, 1.0)
	scale_tween.tween_property(self, "scale", normal_scale, 1.0)


func animate_scale(target: Vector2, duration: float) -> void:
	scale_tween = create_tween()
	scale_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	scale_tween.tween_property(self, "scale", target, duration)


func stop_scale_tween() -> void:
	if scale_tween and scale_tween.is_running():
		scale_tween.kill()


func _on_pressed() -> void:
	get_tree().current_scene.get_node("Panel").popup_centered()
