extends CharacterBody2D

signal defeated

@export var arrow_scene: PackedScene
@export var fire_interval := 1.0
@export var medium_health_fire_interval := 0.5
@export var attack_animation_time := 0.4
@export var fan_arrow_count := 5
@export var fan_spread_degrees := 50.0
@export var ring_arrow_count := 12
@export var max_health := 30

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var damage_sound: AudioStreamPlayer2D = $DamageSound
@onready var health_boss_bar = $HealthBossBar

var health: int
var arrow_spawn: Marker2D
var player: Node2D
var attack_number := 0


func _ready() -> void:
	health = max_health
	health_boss_bar.max_value = max_health
	health_boss_bar.value = health
	add_to_group("enemies")

	arrow_spawn = find_child("SpikeSpawn", true, false) as Marker2D
	if arrow_spawn == null:
		push_error("SpikeSpawn must be a Marker2D inside BossCharacter.")
		return

	sprite.play("idle")
	attack_loop()


func attack_loop() -> void:
	while is_inside_tree():
		if not is_instance_valid(player):
			player = get_tree().get_first_node_in_group("player") as Node2D

		var wait_time := fire_interval
		if is_in_medium_health_phase():
			wait_time = medium_health_fire_interval

		if is_instance_valid(player) and arrow_scene != null:
			sprite.play("attack")

			if is_in_medium_health_phase():
				match attack_number % 3:
					0:
						fire_fan()
					1:
						fire_ring()
					2:
						fire_aimed_burst()
			else:
				if attack_number % 3 == 2:
					fire_ring()
				else:
					fire_fan()

			attack_number += 1

			var animation_time := minf(attack_animation_time, wait_time)
			await get_tree().create_timer(animation_time).timeout

			if not is_inside_tree():
				return

			sprite.play("idle")

			var remaining_wait := wait_time - animation_time
			if remaining_wait > 0.0:
				await get_tree().create_timer(remaining_wait).timeout
		else:
			sprite.play("idle")
			await get_tree().create_timer(wait_time).timeout


func is_in_medium_health_phase() -> bool:
	return health <= max_health / 2


func fire_fan() -> void:
	var aim_direction := (
		player.global_position - arrow_spawn.global_position
	).normalized()
	var spread := deg_to_rad(fan_spread_degrees)

	for i in range(fan_arrow_count):
		var fraction := 0.0
		if fan_arrow_count > 1:
			fraction = float(i) / float(fan_arrow_count - 1)

		var angle := lerpf(-spread / 2.0, spread / 2.0, fraction)
		spawn_arrow(aim_direction.rotated(angle))


func fire_ring() -> void:
	for i in range(ring_arrow_count):
		var angle := TAU * float(i) / float(ring_arrow_count)
		spawn_arrow(Vector2.RIGHT.rotated(angle))


func fire_aimed_burst() -> void:
	var aim_direction := (
		player.global_position - arrow_spawn.global_position
	).normalized()
	var spread := deg_to_rad(20.0)

	for i in range(3):
		var angle := lerpf(-spread, spread, float(i) / 2.0)
		spawn_arrow(aim_direction.rotated(angle))


func spawn_arrow(arrow_direction: Vector2) -> void:
	var arrow = arrow_scene.instantiate()
	call_deferred("_add_arrow", arrow, arrow_direction.normalized())


func _add_arrow(arrow: Node2D, arrow_direction: Vector2) -> void:
	if not is_instance_valid(arrow) or not is_inside_tree():
		return

	arrow.set("direction", arrow_direction)
	get_tree().current_scene.add_child(arrow)
	arrow.global_position = arrow_spawn.global_position
	arrow.rotation = arrow_direction.angle()


func take_damage(amount: int) -> void:
	if health <= 0:
		return

	health = maxi(health - amount, 0)
	health_boss_bar.value = health
	damage_sound.play()
	print("Boss health: ", health, "/", max_health)

	if health == 0:
		defeated.emit()
		queue_free()
