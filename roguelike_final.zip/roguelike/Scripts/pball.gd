extends CharacterBody2D

signal returned

@export var speed := 700.0
@export var max_bounces := 5
@export var catch_distance := 56.0

@export var spin_speed := 12.0
@export var trail_width := 3.0
@export var trail_length_points := 9

@onready var ball_sprite: Sprite2D = $Sprite2D
@onready var trail: Line2D = $Trail
@onready var throw_sound: AudioStreamPlayer2D = $ThrowSound
@onready var bounce_sound: AudioStreamPlayer2D = $BounceSound

var direction := Vector2.ZERO
var bounces_left := 0
var returning := false
var player: CharacterBody2D


func _ready() -> void:
	add_to_group("balls")

	trail.set_as_top_level(true)
	trail.width = trail_width
	trail.default_color = Color.RED
	trail.clear_points()

	for node in get_tree().get_nodes_in_group("player"):
		if node is CharacterBody2D:
			player = node
			add_collision_exception_with(player)
			break


func launch(throw_direction: Vector2) -> void:
	direction = throw_direction.normalized()
	bounces_left = max_bounces
	throw_sound.play()


func _physics_process(delta: float) -> void:
	if not is_instance_valid(player):
		queue_free()
		return

	ball_sprite.rotation += spin_speed * delta

	if returning:
		direction = (player.global_position - global_position).normalized()

	var collision := move_and_collide(direction * speed * delta)
	update_trail()

	if collision:
		bounce_sound.play()
		var hit := collision.get_collider()

		if not returning:
			if (
				hit is Node
				and hit.is_in_group("enemies")
				and hit.has_method("take_damage")
			):
				hit.take_damage(1)

			direction = direction.bounce(collision.get_normal()).normalized()
			bounces_left -= 1

			if bounces_left <= 0:
				returning = true
		else:
			direction = direction.bounce(collision.get_normal()).normalized()

	if returning and global_position.distance_to(player.global_position) <= catch_distance:
		return_to_player()


func try_collect(collector: Node2D) -> bool:
	if collector != player:
		return false

	if global_position.distance_to(player.global_position) > catch_distance:
		return false

	return_to_player()
	return true


func update_trail() -> void:
	trail.add_point(global_position)

	while trail.get_point_count() > trail_length_points:
		trail.remove_point(0)


func return_to_player() -> void:
	returned.emit()
	trail.clear_points()
	queue_free()
