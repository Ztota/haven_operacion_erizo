extends TextureButton

@export var idle_zoom := 1.08
@export var hover_zoom := 1.2
@export var animation_time := 0.5

var scale_tween: Tween


func _ready() -> void:
	pivot_offset = size / 2.0
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)
	start_idle_pulse()


func start_idle_pulse() -> void:
	if scale_tween and scale_tween.is_running():
		scale_tween.kill()

	scale_tween = create_tween().set_loops()
	scale_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	scale_tween.tween_property(
		self, "scale", Vector2.ONE * idle_zoom, animation_time
	)
	scale_tween.tween_property(
		self, "scale", Vector2.ONE, animation_time
	)


func _on_mouse_entered() -> void:
	if scale_tween and scale_tween.is_running():
		scale_tween.kill()

	scale_tween = create_tween()
	scale_tween.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	scale_tween.tween_property(
		self, "scale", Vector2.ONE * hover_zoom, 0.2
	)


func _on_mouse_exited() -> void:
	start_idle_pulse()
