extends TextureButton





func _on_pressed() -> void:
	get_tree().current_scene.get_node("Panel").hide()
