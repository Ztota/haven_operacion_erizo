extends Node2D

@export var player_scene: PackedScene
@export var victory_scene: PackedScene

@onready var player_spawn: Marker2D = $PlayerSpawn
@onready var game_over_menu: Control = $CanvasLayer/GameOverMenu
@onready var retry_button: TextureButton = $CanvasLayer/GameOverMenu/RetryButton
@onready var game_over_music: AudioStreamPlayer2D = $GameOverMusic

var boss_defeated := false


func _ready() -> void:
	game_over_menu.hide()
	retry_button.pressed.connect(_on_retry_button_pressed)

	spawn_player()

	for enemy in get_tree().get_nodes_in_group("enemies"):
		if enemy.has_signal("defeated"):
			enemy.defeated.connect(_on_boss_defeated)


func spawn_player() -> void:
	if player_scene == null:
		push_error("Assign the player scene in the Inspector.")
		return

	var player = player_scene.instantiate()
	add_child(player)
	player.global_position = player_spawn.global_position
	player.died.connect(_on_player_died)


func _on_player_died() -> void:
	for music in get_tree().get_nodes_in_group("music"):
		if music is AudioStreamPlayer or music is AudioStreamPlayer2D:
			music.stop()

	game_over_menu.show()
	retry_button.grab_focus()
	game_over_music.play()


func _on_retry_button_pressed() -> void:
	get_tree().reload_current_scene()


func _on_boss_defeated() -> void:
	if boss_defeated:
		return

	boss_defeated = true

	if victory_scene == null:
		push_error("Assign the victory scene in the Inspector.")
		return

	get_tree().change_scene_to_packed(victory_scene)
