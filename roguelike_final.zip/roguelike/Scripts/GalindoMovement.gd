extends CharacterBody2D

signal defeated

@export var arrow_scene: PackedScene
@export var fire_interval := 1.0
@export var medium_health_fire_interval := 0.5
@export var attack_animation_time := 0.4
@export var fan_arrow_count := 5
@export var fan_spread_degrees := 50.0
@export var ring_arrow_count := 12
@export var max_health := 30

@onready var sprite: Sprite2D = $Sprite2D
@onready var galindo_bar = $GalindoBar
@export var velocidad := 50.0
@export var tiempo_entre_pasos := Vector2(1.0, 3.0)

var health: int
var direccion := Vector2.ZERO
var reloj := 0.0

func _ready() -> void:
	health = max_health
	galindo_bar.max_value = max_health
	galindo_bar.value = health
	add_to_group("enemies")
	
func _physics_process(delta: float) -> void:
	reloj -= delta

	if reloj <= 0.0:
		elegir_direccion()
		reloj = randf_range(tiempo_entre_pasos.x, tiempo_entre_pasos.y)

	velocity = direccion * velocidad
	move_and_slide()

	if get_slide_collision_count() > 0:
		elegir_direccion()
		reloj = 0.5

func elegir_direccion() -> void:
	if randf() < 0.25:
		direccion = Vector2.ZERO
	else:
		var angulo := randf_range(0.0, TAU)
		direccion = Vector2.RIGHT.rotated(angulo)


func take_damage(amount: int) -> void:
	if health <= 0:
		return

	health = maxi(health - amount, 0)
	galindo_bar.value = health
	print("Boss health: ", health, "/", max_health)

	if health == 0:
		defeated.emit()
		queue_free()
